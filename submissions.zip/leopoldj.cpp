/*
  This is Leopold's submission
*/
#include <stdio.h>
#include <iostream>
using namespace std;

int factorial(int n)
{
  if (n > 0)
    return(n * factorial(n-1));
  else return(1);
}

int main()
{
  int n;
  cin >> n;

  cout << factorial(n) << endl;
  if (n > 10)
  {
    cin >> n;  // don't want it to change this one!
    double d = log(n);
    cout << d;
  }
  return 0;
} 

