// This is Morales' submission
//
#include <iostream>
using namespace std;
#include <math.h>

int multiply(int n)
{
  return(n*100);
}

int main()
{
  int n;
  int m = 2;
  cin >> n;

  cout << multiply(n+2) << endl;
  return 0;
} 

