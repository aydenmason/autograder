// Clayton Price
// CS 1570
// Spring 2020

#include <stdio.h>

void print()
{
  int n;
  cin >> n;
  printf("%d\n", n);
}

int main()
{
  int n;
  n = 2;
  cin >> n;

  printf("%d\n", n);
  return 0;
} 

